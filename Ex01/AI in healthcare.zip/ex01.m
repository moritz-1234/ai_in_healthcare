importdata("ex1_data.mat");

bw = normalize(BirthWeight);
ga = normalize(GestationalAge);

m = 17;
t0 = 0;
t1 = 0;
a = 0.01;
num_iterations = 1000;
J=1:num_iterations;
for j =  1:num_iterations
    sum0 = 0;
    sum1 = 0;
    sumCost = 0; 
    for k = 1:m %build sums
        sum0 =sum0+ (t0+t1*bw(k))-ga(k);
        sum1 =sum1+ ((t0+t1*bw(k))-ga(k))*bw(k);
        sumCost = sumCost + ((t0+t1*bw(k))-ga(k))^2;
    end

    t0 = t0-a*(1/m)*sum0; %theta0
    t1 = t1-a*(1/m)*sum1; %theta1
    J(j) = (1/(2*m))*sumCost; %save steps of cost function in vector
end
tiledlayout(2,1); %split graph in 2
nexttile; %first graph
hold on; %mix 2 graphs for 1st graph (line and data)
scatter(bw, ga); %plot data
x = linspace(-5, 5); %plot line between -5 and 5
plot(x,t0+t1*x);
title("Data");
hold off;
nexttile; %second graph
plot(1:num_iterations, J);
title("Cost function");
disp(t0);
disp(t1);

